﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Speech.Synthesis;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace CybersecurityChatBot_2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly CyberBotEngine _botEngine;
        private readonly SpeechSynthesizer? _speechSynthesizer;
        private bool _isMuted = false;

        public MainWindow()
        {
            InitializeComponent();
            _botEngine = new CyberBotEngine();

            try
            {
                _speechSynthesizer = new SpeechSynthesizer();
                _speechSynthesizer.SetOutputToDefaultAudioDevice();
            }
            catch { _speechSynthesizer = null; }

            DisplayWelcomeScreen();
            ToggleChatControls(false);
        }

        private void DisplayWelcomeScreen()
        {
            AppendBotMessage("\n  Welcome to CyberGuard! Please enter your name to begin.\n", Brushes.Cyan, true);
        }

        private void ToggleChatControls(bool enable)
        {
            if (UserInputTextBox != null) UserInputTextBox.IsEnabled = enable;
            if (SendButton != null) SendButton.IsEnabled = enable;
            if (ChatHistoryButton != null) ChatHistoryButton.IsEnabled = enable;
            if (PhishingRadioButton != null) PhishingRadioButton.IsEnabled = enable;
            if (PasswordRadioButton != null) PasswordRadioButton.IsEnabled = enable;
            if (MFARadioButton != null) MFARadioButton.IsEnabled = enable;
            if (MalwareRadioButton != null) MalwareRadioButton.IsEnabled = enable;
            if (FirewallRadioButton != null) FirewallRadioButton.IsEnabled = enable;
            if (VPNRadioButton != null) VPNRadioButton.IsEnabled = enable;
            if (SocialEngineeringRadioButton != null) SocialEngineeringRadioButton.IsEnabled = enable;
            if (GeneralTipsRadioButton != null) GeneralTipsRadioButton.IsEnabled = enable;
            if (PrivacyRadioButton != null) PrivacyRadioButton.IsEnabled = enable;
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            string name = UserNameTextBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(name) || !Regex.IsMatch(name, "^[a-zA-Z][a-zA-Z ]*$"))
            {
                NameErrorTextBlock.Text = "Please enter a valid name (letters only).";
                Speak("Please enter a valid name.");
            }
            else
            {
                _botEngine.UserName = name;
                NameEntrySection.Visibility = Visibility.Collapsed;
                ToggleChatControls(true);
                string welcome = $"Hello {_botEngine.UserName}! I'm CyberGuard. I've started our session log. How can I help you today? You can ask for 'tips' or 'prevention' on any topic!";
                AppendBotMessage($"  {welcome}", Brushes.Cyan, true);
                Speak(welcome);
            }
        }

        private void btnSend_Click(object sender, RoutedEventArgs e) => ProcessInput();

        private void txtInput_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter) ProcessInput();
        }

        private void txtName_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter) btnStart_Click(sender, e);
        }

        private void TopicRadio_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is RadioButton rb && rb.IsChecked == true)
            {
                UserInputTextBox.Text = rb.Content.ToString();
                ProcessInput();
                rb.IsChecked = false;
            }
        }

        private void ProcessInput()
        {
            string input = UserInputTextBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(input)) return;

            AppendUserMessage(input);
            string response = _botEngine.GetBotResponse(input);
            AppendBotMessage(response, Brushes.Cyan, true);
            Speak(response);
            UserInputTextBox.Clear();
        }

        private void ChatHistoryButton_Click(object sender, RoutedEventArgs e)
        {
            string fullHistory = _botEngine.GetFullChatHistory();
            Window historyWindow = new Window
            {
                Title = "Full Chat History Report",
                Width = 600,
                Height = 500,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                Background = new SolidColorBrush(Color.FromRgb(30, 30, 30))
            };

            TextBox historyBox = new TextBox
            {
                Text = fullHistory,
                IsReadOnly = true,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Background = new SolidColorBrush(Color.FromRgb(45, 45, 48)),
                Foreground = Brushes.LightGray,
                FontFamily = new FontFamily("Consolas"),
                Padding = new Thickness(10),
                TextWrapping = TextWrapping.Wrap
            };

            historyWindow.Content = historyBox;
            historyWindow.ShowDialog();
        }

        private void AppendBotMessage(string message, SolidColorBrush color, bool log)
        {
            Dispatcher.Invoke(() => {
                if (ChatDisplay != null)
                {
                    TextRange tr = new TextRange(ChatDisplay.Document.ContentEnd, ChatDisplay.Document.ContentEnd);
                    tr.Text = "🤖 CyberGuard » " + message + "\n\n";
                    tr.ApplyPropertyValue(TextElement.ForegroundProperty, color);
                    ChatDisplay.ScrollToEnd();
                }
                if (log) _botEngine.LogMessage("CyberGuard", message);
            });
        }

        private void AppendUserMessage(string message)
        {
            Dispatcher.Invoke(() => {
                if (ChatDisplay != null)
                {
                    TextRange tr = new TextRange(ChatDisplay.Document.ContentEnd, ChatDisplay.Document.ContentEnd);
                    tr.Text = "👤 You » " + message + "\n\n";
                    tr.ApplyPropertyValue(TextElement.ForegroundProperty, Brushes.LightGreen);
                    ChatDisplay.ScrollToEnd();
                }
                _botEngine.LogMessage(_botEngine.UserName ?? "User", message);
            });
        }

        private void Speak(string text)
        {
            if (_speechSynthesizer != null && !_isMuted)
            {
                try { _speechSynthesizer.SpeakAsync(text); } catch { }
            }
        }

        private void btnSpeak_Click(object sender, RoutedEventArgs e)
        {
            if (_speechSynthesizer != null)
            {
                if (_isMuted)
                {
                    _speechSynthesizer.Volume = 100;
                    MuteToggleButton.Content = "Mute Voice";
                }
                else
                {
                    _speechSynthesizer.SpeakAsyncCancelAll();
                    _speechSynthesizer.Volume = 0;
                    MuteToggleButton.Content = "Unmute Voice";
                }
                _isMuted = !_isMuted;
            }
        }
    }

    public class CyberBotEngine
    {
        public string? UserName { get; set; }
        private string _currentTopicKey = string.Empty;
        private readonly Dictionary<string, CyberTopic> _knowledgeBase;
        private readonly List<ChatMessage> _history = new List<ChatMessage>();
        private Random _random = new Random();

        public CyberBotEngine()
        {
            _knowledgeBase = new Dictionary<string, CyberTopic>(StringComparer.OrdinalIgnoreCase);
            InitializeKnowledgeBase();
        }

        private void InitializeKnowledgeBase()
        {
            AddTopic("vpn", "VPN (Virtual Private Network)",
                new[] {
                    "A VPN creates a private, encrypted 'tunnel' across a public network.",
                    "It masks your IP address to prevent tracking.",
                    "It protects you on public Wi-Fi from hackers.",
                    "Always look for a 'No-Logs' policy and a 'Kill Switch'."
                },
                new[] {
                    "Tip: Use a VPN whenever you connect to public Wi-Fi at cafes or airports.",
                    "Tip: Paid VPNs are generally more secure and private than free versions.",
                    "Tip: Check if your VPN has servers in multiple countries for better speed and access."
                },
                new[] {
                    "Prevention: A VPN prevents 'Man-in-the-Middle' attacks on public networks.",
                    "Prevention: It stops ISPs from selling your browsing history to third parties.",
                    "Prevention: Use a VPN to hide your location from websites that track your physical address."
                });

            AddTopic("phishing", "Phishing Awareness",
                new[] {
                    "Phishing is a technique to trick you into revealing data.",
                    "Over 3 billion phishing emails are sent daily.",
                    "Never click links in unexpected emails.",
                    "Check the 'Return-Path' in email headers for inconsistencies."
                },
                new[] {
                    "Tip: Hover over links in emails to see the actual destination URL before clicking.",
                    "Tip: Be wary of emails that create a false sense of urgency (e.g., 'Your account will be deleted in 24 hours').",
                    "Tip: Use a modern browser with built-in phishing protection enabled."
                },
                new[] {
                    "Prevention: Never share your passwords or MFA codes via email or text.",
                    "Prevention: If you receive a suspicious email from a 'bank', call the bank directly using a number from their official website.",
                    "Prevention: Enable email filtering and use an anti-phishing browser extension."
                });

            AddTopic("password", "Password Security",
                new[] {
                    "Strong passwords are the bedrock of digital safety.",
                    "A 12-character mixed password takes 3,000 years to crack.",
                    "Use unique passwords for every account.",
                    "Adopt a 'Passphrase' strategy for better security."
                },
                new[] {
                    "Tip: Use a password manager like Bitwarden or LastPass to generate and store complex passwords.",
                    "Tip: Create 'Passphrases' by combining 4-5 random words (e.g., 'Correct-Horse-Battery-Staple').",
                    "Tip: Avoid using personal information like birthdays or pet names in your passwords."
                },
                new[] {
                    "Prevention: Change your passwords immediately if you suspect an account has been breached.",
                    "Prevention: Don't write passwords on sticky notes near your computer.",
                    "Prevention: Use different passwords for your email and banking accounts to prevent 'credential stuffing'."
                });

            AddTopic("mfa", "Multi-Factor Authentication",
                new[] {
                    "MFA requires two or more verification methods.",
                    "MFA blocks 99.9% of automated compromise attacks.",
                    "Hackers cannot bypass the second factor easily.",
                    "Prefer Authenticator Apps over SMS codes."
                },
                new[] {
                    "Tip: Use an app like Google Authenticator or Microsoft Authenticator instead of SMS codes.",
                    "Tip: Always save your 'Backup Codes' in a secure, offline location in case you lose your phone.",
                    "Tip: Enable MFA on your primary email account first, as it's the gateway to all other accounts."
                },
                new[] {
                    "Prevention: MFA prevents hackers from accessing your account even if they steal your password.",
                    "Prevention: Be alert for 'MFA Fatigue' attacks where hackers spam you with login requests.",
                    "Prevention: Never approve an MFA request that you didn't initiate yourself."
                });

            AddTopic("malware", "Malware Protection",
                new[] {
                    "Malware includes viruses, ransomware, and spyware.",
                    "Modern malware can be 'fileless' and hide in memory.",
                    "Keep your OS and browsers updated with patches.",
                    "Use a 'Standard' user account for daily tasks."
                },
                new[] {
                    "Tip: Regularly back up your important files to an external drive or cloud storage to protect against ransomware.",
                    "Tip: Use a reputable antivirus software and keep it updated daily.",
                    "Tip: Be cautious of 'free' software downloads, which often come bundled with 'bloatware' or malware."
                },
                new[] {
                    "Prevention: Only download software from official websites and trusted app stores.",
                    "Prevention: Keep your operating system and all applications updated to patch security vulnerabilities.",
                    "Prevention: Don't click on pop-up ads that claim your computer is 'infected'."
                });

            AddTopic("firewall", "Network Firewalls",
                new[] {
                    "A firewall monitors and controls network traffic.",
                    "Use both hardware and software firewalls.",
                    "It blocks unauthorized probes from the internet.",
                    "Disable 'UPnP' on your router for better security."
                },
                new[] {
                    "Tip: Ensure your Windows or macOS built-in firewall is always turned on.",
                    "Tip: Check your router settings to ensure its hardware firewall is active.",
                    "Tip: If you're a gamer, only open specific ports (Port Forwarding) when absolutely necessary."
                },
                new[] {
                    "Prevention: Firewalls prevent hackers from scanning your computer for open vulnerabilities.",
                    "Prevention: They can block malicious software from 'calling home' to a hacker's server.",
                    "Prevention: A properly configured firewall is your first line of defense against network-based attacks."
                });

            AddTopic("social engineering", "Social Engineering",
                new[] {
                    "Social Engineering manipulates people into giving info.",
                    "Hackers exploit human traits like trust and fear.",
                    "Be skeptical of unsolicited calls or emails.",
                    "Verify suspicious bank calls by calling back directly."
                },
                new[] {
                    "Tip: Be wary of anyone asking for information they should already have (like your bank asking for your account number).",
                    "Tip: If a deal sounds too good to be true (like a free prize), it's probably a social engineering trap.",
                    "Tip: Practice 'Healthy Skepticism' when dealing with strangers online or over the phone."
                },
                new[] {
                    "Prevention: Never give out sensitive information over the phone unless you initiated the call.",
                    "Prevention: Train yourself to recognize 'Pretexting' where someone creates a fake scenario to get your data.",
                    "Prevention: Be careful about what personal details you share on social media, as hackers use them to build trust."
                });

            AddTopic("general tips", "General Cybersecurity Tips",
                new[] {
                    "95% of breaches are caused by human error.",
                    "Use a password manager and enable MFA.",
                    "Keep your software updated regularly.",
                    "Be cautious of unsolicited communications."
                },
                new[] {
                    "Tip: Treat your digital life like your physical life—don't leave your 'doors' unlocked.",
                    "Tip: Regularly review your bank statements for any unauthorized transactions.",
                    "Tip: Use a privacy-focused search engine like DuckDuckGo to reduce tracking."
                },
                new[] {
                    "Prevention: Education is the best prevention. Stay informed about the latest cyber threats.",
                    "Prevention: Use a non-administrator account for your daily computer tasks to limit potential damage from malware.",
                    "Prevention: Encrypt your computer's hard drive (using BitLocker or FileVault) to protect data if it's stolen."
                });

            AddTopic("privacy", "Online Privacy",
                new[] {
                    "Many free services monetize your personal data.",
                    "Use privacy-focused browsers like Brave or Firefox.",
                    "Review privacy settings on social media accounts.",
                    "Limit what information you share publicly."
                },
                new[] {
                    "Tip: Regularly clear your browser cookies and cache to limit cross-site tracking.",
                    "Tip: Use 'Incognito' or 'Private' mode when searching for sensitive topics.",
                    "Tip: Read the privacy policy of apps before granting them access to your contacts or location."
                },
                new[] {
                    "Prevention: Use a 'burner' email address for one-time signups to avoid spam and tracking.",
                    "Prevention: Disable 'Location Services' for apps that don't strictly need it.",
                    "Prevention: Be mindful of 'Over-sharing' on social media, which can lead to identity theft."
                });
        }

        private void AddTopic(string key, string name, string[] steps, string[] tips, string[] prevention)
        {
            _knowledgeBase[key] = new CyberTopic
            {
                Name = name,
                Steps = steps.ToList(),
                Tips = tips.ToList(),
                Prevention = prevention.ToList()
            };
        }

        public string GetBotResponse(string input)
        {
            string lowerInput = input.ToLower();
            _history.Add(new ChatMessage { Sender = UserName ?? "User", Message = input, Timestamp = DateTime.Now });

            // Check for a new topic
            foreach (var topic in _knowledgeBase)
            {
                if (lowerInput.Contains(topic.Key))
                {
                    _currentTopicKey = topic.Key;
                    return $"I see you're interested in {topic.Value.Name}. {topic.Value.Steps[0]} You can ask for 'tips', 'prevention', or 'more' information on this!";
                }
            }

            // If a topic is active, handle specific requests
            if (!string.IsNullOrEmpty(_currentTopicKey))
            {
                var topic = _knowledgeBase[_currentTopicKey];

                if (lowerInput.Contains("tip"))
                {
                    return topic.Tips[_random.Next(topic.Tips.Count)];
                }

                if (lowerInput.Contains("prevent"))
                {
                    return topic.Prevention[_random.Next(topic.Prevention.Count)];
                }

                if (lowerInput.Contains("more") || lowerInput.Contains("next") || lowerInput.Contains("fact"))
                {
                    // Combine steps, tips, and prevention for 'more' info
                    var allInfo = topic.Steps.Concat(topic.Tips).Concat(topic.Prevention).ToList();
                    return allInfo[_random.Next(allInfo.Count)];
                }
            }

            return "I'm not sure I understand. Try asking about VPNs, Phishing, or Passwords. You can also ask for 'tips' or 'prevention'!";
        }

        public void LogMessage(string sender, string message)
        {
            _history.Add(new ChatMessage { Sender = sender, Message = message, Timestamp = DateTime.Now });
        }

        public string GetFullChatHistory()
        {
            return string.Join("\n", _history.Select(h => $"[{h.Timestamp:HH:mm:ss}] {h.Sender}: {h.Message}"));
        }
    }

    public class CyberTopic
    {
        public string Name { get; set; } = string.Empty;
        public List<string> Steps { get; set; } = new List<string>();
        public List<string> Tips { get; set; } = new List<string>();
        public List<string> Prevention { get; set; } = new List<string>();
    }

    public class ChatMessage
    {
        public string Sender { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; }
    }
}
